About the hours, it will be accepted if the year is diplayed in the case of the exercise’s date (1 Jun) is outdated by six month or more.

To modify dates and times for file access, modification, and creation, you can use the touch command followed by the -a, -m, or -c options, followed by YYYYMMDDHHMM.SS. 
